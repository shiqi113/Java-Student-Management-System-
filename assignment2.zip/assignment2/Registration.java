
package assignment2;
/**
 *
 * @author TAN SHI QI
 * b1901264
 */
import java.util.Scanner;
public class Registration {
    public static void main(String[] args){
        String name,studentID,programme,supervisor,designation,status="";
        char statusChoice;
        //int creditsCompleted=0;
        Scanner input = new Scanner(System.in);
        System.out.print(" Enter size of the list: ");
        int noofList=input.nextInt();
        StudentList  student_List;
        student_List=new StudentList(noofList);
        Course CourseList;
        
        System.out.println("");
        input.nextLine();
        System.out.println("1 --> Add Undergrad student ");
        System.out.println("2 --> Add Postgrad Student ");
        System.out.println("3 --> Set Status ");
        System.out.println("4 --> Register course ");
        System.out.println("5 --> All Registered Students ");
        System.out.println("Q/q --> Quit");
        System.out.println("");
        System.out.print("Enter your choice:");
        String choice = input.nextLine();
        while(!(choice.equalsIgnoreCase("q"))){
            switch (choice) {
                case "1":
                    System.out.print("Enter name:");
                    name = input.nextLine();
                    System.out.print("Enter ID:");
                    studentID = input.nextLine();
                    System.out.print("Enter Programme: ");
                    programme = input.nextLine();
                    System.out.print("Enter Credits completed: ");
                    int creditsCompleted = input.nextInt();
                    student_List.addStudent(new UnderGrad(name,studentID,programme,creditsCompleted));
                    //System.out.println(student_List);
                    input.nextLine();
                    break;
                    
                case"2":
                     System.out.print("Enter name:");
                     name = input.nextLine();
                     System.out.print("Enter ID:");
                     studentID = input.nextLine();
                     System.out.print("Enter Programme: ");
                     programme = input.nextLine();
                     System.out.print("Enter Supervisor Name: ");
                     supervisor=input.nextLine();
                     System.out.print("Enter Supervisor Designation:");
                     designation=input.nextLine();
                     Academic academic= new Academic(supervisor,designation);
                     PostGrad ptgd=new PostGrad(name,studentID,programme,academic,status);
                     student_List.addStudent(new PostGrad (name,studentID,programme,academic,status));
                     //System.out.println(student_List);
                     break;
                case"3":
                     System.out.print("Enter ID:");
                     studentID = input.nextLine();
                     System.out.println("R -> RESEARCH");
                     System.out.println("T -> THESIS WRITING");
                     System.out.print("Enter Choice:");
                     statusChoice=input.next().charAt(0);
                    
                     if (statusChoice=='R'||statusChoice=='r'){
                         status="RESERCH";
                         
                    }
                    else if (statusChoice=='T'||statusChoice=='t'){
                        status="THESIS WRITING";
                    }
                    student_List.setSatus(studentID,status);
                    //System.out.println(student_List);
                    break;
                case"4":
                    System.out.print("Enter Id:");
                    studentID=input.nextLine();
                    System.out.print("Enter Course Name:");
                    String coursename = input.nextLine();
                    System.out.print(" Enter Course code: ");
                    String code = input.nextLine();
                    Course course = new Course(coursename,code);
                    student_List.registerCourse(studentID,course);
                    break;
                    //System.out.println(course);
                 case"5":
                     System.out.println(student_List);
                     break;
                     
            }
        System.out.println("");
        System.out.println("1 --> Add Undergrad student ");
        System.out.println("2 --> Add Postgrad Student ");
        System.out.println("3 --> Set Status ");
        System.out.println("4 --> Register course ");
        System.out.println("5 --> All Registered Students ");
        System.out.println("Q/q --> Quit");
        System.out.println("");
        System.out.print("Enter your choice:");
        choice = input.nextLine();
        }
    }     
}


       
        
      
    
    

