
package assignment2;
/**
 *
 * @author TAN SHI QI
 * b1901264
 */
public class Academic {
    private String name;
    private String designation;
    
    Academic(String name, String designation) {
        this.name = name;
        this.designation = designation;
    }
    
    public String toString(){
        return designation + " " + name;
    }
    
}
