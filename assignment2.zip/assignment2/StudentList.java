
package assignment2;
/**
 *
 * @author TAN SHI QI
 * b1901264
 */
public class StudentList {
    private int noOfStudents;
    private Student[] studentList;
    private int MAXSTUDENTS ;
    private UnderGrad [] undergrad;
    private PostGrad [] postgrad;
    private int uStudent,pStudent=0;
    //cons
    StudentList(int max){
        MAXSTUDENTS = max;
        studentList = new Student[MAXSTUDENTS]; 
        noOfStudents = 0;
        undergrad=new UnderGrad[MAXSTUDENTS];
        postgrad=new PostGrad[MAXSTUDENTS];
    }
    //method for add student in list
    public boolean addStudent(Student student){
        if(noOfStudents!=MAXSTUDENTS){
            studentList[noOfStudents]=student;
             if (studentList[noOfStudents] instanceof UnderGrad){
                undergrad[uStudent]= new UnderGrad(studentList[noOfStudents]);
                uStudent++;
            }
            else  if (studentList[noOfStudents] instanceof PostGrad){
                postgrad[pStudent]= new PostGrad(studentList[noOfStudents]);
                pStudent++;
            }
            noOfStudents++;
            return true;
        }
        else{
            System.out.println("Cannot add student,the list is full");
            return false;// cannot add any more student, MAX SIZE reached
        }
    }
    //method for set status ito the list
    public int setSatus(String studentID,String status){
       int result=0,data=0;
        for (int i=0;i<pStudent;i++){
            if (postgrad[i].getId().equalsIgnoreCase(studentID)){
                for (int count=0;count<noOfStudents;count++){
                    if(studentList[count].getId()==postgrad[i].getId()){
                        data=count;
                    }
                }
                postgrad[i].setStatus(status);
                studentList[data]=postgrad[i];
                result=1;
            }
        }
        if (result==1){
            System.out.println("Set Successful!!!");
        }
        else{
            System.out.println("Invalid ID!!!");
        }
        return result;
    } 
    //method foe register Course to the list
    public int registerCourse(String studentID, Course course){
       
        int result=0;
        int term=0;
        for (int i=0;i<uStudent;i++){
            if (undergrad[i].getId().equalsIgnoreCase(studentID)){
                for (int count=0;count<noOfStudents;count++){
                    if(studentList[count].getId()==undergrad[i].getId()){
                        term=count;
                    }
                }
               undergrad[i].registerCourse(course);
                studentList[term]=undergrad[i];
                result=1;
            }
        }
        if (result==1){
            System.out.println("Addition success!");
        }
        else{
            System.out.println("Invalid ID!");
        }
        return result;
    }

    
    public String toString(){
        String result ="";
       
        for(int i = 0; i < noOfStudents ; i++){
            result += studentList[i].toString();
            result += "\n-------------------------------";
        }        
        return result;
    }   
    
    
    
}
