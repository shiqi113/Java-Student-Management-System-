
package assignment2;
/**
 *
 * @author TAN SHI QI
 * b1901264
 */
abstract public class Student {
    
    private String name;
    private String studentID;
    protected String programme;
    private int creditsCompleted;
    private Academic supervisor;
    private String status="AUDIT";
    String result="";
    //cons Undergrad
    Student(String name , String studentID, String programme,int creditsCompleted ){
        this.name = name;
        this.studentID = studentID;
        this.programme = programme;
        this.creditsCompleted=creditsCompleted;
        
    }   
    //cons Postgrad
    Student(String name , String studentID, String programme,Academic supervisor){
        this.name = name;
        this.studentID = studentID;
        this.programme = programme;
        this.supervisor=supervisor;
    }
    //getter
    public String getId(){
        return studentID;
    }
    
    public String getName(){
        return name;
    }

     public String getProgramme(){
        return programme;
    }

    public int getCreditsCompleted(){
        return creditsCompleted;
    }
    
    public Academic getSupervisor(){
        return supervisor;
    }
    
    abstract double calculateSemFee();
    public String toString(){
        // user choose b or B will show this message
        if (programme.charAt(0)=='B'||programme.charAt(0)=='b'){
            result= "\nStudent: " + name + " ID: " + studentID + " pursuing " + 
                    programme+ "has completed " +creditsCompleted +" credits";
        }
        //user choose choose p,P,m,M will show this message
        else if (programme.charAt(0)=='p'||programme.charAt(0)=='P'||programme.charAt(0)=='m'||programme.charAt(0)=='M'){
            result= "\nStudent: " + name + " ID: " + studentID + " pursuing " + programme;
        }
        return result;
        
    }
       
    
}