
package assignment2;
/**
 *
 * @author TAN SHI QI
 * b1901264
 */
public class PostGrad extends Student {
    //private String name;
    //private String studentid;
    private String programme;
    private Academic supervisor;
    private String status;
    private double total;
    char program;
    //cons
    PostGrad(Student student){
        super(student.getName(),student.getId(),student.getProgramme(),student.getSupervisor());
        programme=student.getProgramme();
        program=programme.charAt(0);
        supervisor=student.getSupervisor();
    }
   
    PostGrad(String name,String id,String programme, Academic supervisor,String status){
        super(name, id, programme,supervisor);
        this.programme=programme;
        program=programme.charAt(0);
        this.status=status;
        this.supervisor=supervisor;
     
    }
    //setter
     public boolean setStatus(String status){
         this.status=status;
         return true;  
         
    }
     //method calculate sem fee
     public double calculateSemFee(){
        
        program=this.programme.charAt(0);
        if (program=='m' || program =='M'){
            total=6000;
        }
        if (program=='p' || program =='P'){
            total=8000;
        }
    return total;
    }
     public  String toString(){
        return super.toString() + "( " + status + " ) is under the supervision of "+ supervisor+"\n"+"and has semester tuition fee: RM"+calculateSemFee();
    }
    
}
