
package assignment2;
/**
 *
 * @author TAN SHI QI
 * b1901264
 */

public class UnderGrad extends Student{
    // instance vars
    private int creditsCompleted;
    private String studentID;
    private Course[] CourseList=new Course[4];
    int SIZE=4;
    int count=0;
    int size;
    private int total=0;
    String coursedata="";
    String udgresult="";
     //cons
    UnderGrad(Student student){
        super(student.getName(),student.getId(),student.getProgramme(),student.getCreditsCompleted());
        studentID=student.getId();
        creditsCompleted=student.getCreditsCompleted();
    }
    
   UnderGrad(String name,String studentID,String programme,int creditsCompleted ){
        super(name, studentID, programme,creditsCompleted);

    }
   
     //getter
    public String getID(){
         return studentID;
    }
    //setter
    public void setCresitsCompleted(int creditsCompleted ){
         creditsCompleted=creditsCompleted;
    }
   
    //method for register course
    public boolean registerCourse(Course CourseListObj){
        
        if ( count == SIZE ) {
            System.out.println("Course cannot be registered : (Maximum reached)");
            return false; // cannot add any more course objs , MAX SIZE reached
        } else {
            if(CourseList[count]==null){
                CourseList[count]=CourseListObj;
                count++;
            }
            else{
                count++;
                CourseList[count]=CourseListObj;
                count++;
                
            }
            
        }
        return true;        
}
    //method calculate see fee
    public double calculateSemFee(){
        total=count*4*500;
        return total;
    }

    public String toString(){
        if (count!=0){
           for(int i = 0; i< count; i++){
               coursedata += CourseList[i].toString();
               coursedata += "\n";
           }
           udgresult= super.toString()+"\nThe student has registered for the following "+ count +" courses this semester \n"+ coursedata+ 
                   "and has semester tuition fee: " + calculateSemFee() + " RM";
       }
       else{//course list empty show this message
           udgresult=super.toString()+ "\nThe student has not registered for any courses this semester"+"\n and has semester tuition fee: " + calculateSemFee();
       }
       return udgresult; 
    }
 
}
   

