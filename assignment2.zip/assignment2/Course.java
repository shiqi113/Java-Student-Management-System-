
package assignment2;
/**
 *
 * @author TAN SHI QI
 * b1901264
 */
public class Course {
    private String coursename;
    private String code;
    
    Course(String name, String code){
        this.coursename = name;
        this.code = code;
    }
    public String toString() {
        return code + ": " + coursename;
    }
    
}
